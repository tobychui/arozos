This is a demo module of ArOZ Online Beta System written by Alan Yeung with modification on Tocas UI Template.
This readme file will be shown by the "Help Module".