<html>
<head>
</head>
<script src="FloatWindow.js"></script>
<script>
var uid = "CalcEmbedded";
var fw = new FloatWindow("index.php","Calc","calculator", uid,325,340);
fw.launch();
</script>
</body>
</html>