<html>
<head>
    <link rel="stylesheet" href="../script/tocas/tocas.css">
	<script src="../script/tocas/tocas.js"></script>
	<script src="../script/jquery.min.js"></script>
    <title>計算機範例 | Tocas UI</title>
    <style type="text/css">
        .ts.segment {
            margin: 0 auto;
            width: 300px;
        }
        .button {
            border: 0 !important
        }
    </style>
	</head>
<body>
  <br>
    <!-- 主要文字容器 -->
    <div class="ts text container">
        <div class="ts segment">
            <!-- 輸入欄位 -->
            <div class="ts fluid input">
                <input id="panel" type="text" placeholder="0">
            </div>
            <!-- / 輸入欄位 -->
            <div class="ts hidden divider"></div>
            <!-- 頂部附著按鈕群組 -->
            <div class="ts fluid top attached buttons">
                <button onclick="num('7');" class="ts button">7</button>
                <button onclick="num('8');" class="ts button">8</button>
                <button onclick="num('9');" class="ts button">9</button>
                <button onclick="num('+');" class="ts info button">+</button>
            </div>
            <!-- / 頂部附著按鈕群組 -->

            <!-- 中間附著按鈕群組 -->
            <div class="ts fluid attached buttons">
                <button onclick="num('4');" class="ts button">4</button>
                <button onclick="num('5');" class="ts button">5</button>
                <button onclick="num('6');" class="ts button">6</button>
                <button onclick="num('-');" class="ts info button">-</button>
            </div>
            <!-- / 中間附著按鈕群組 -->

            <!-- 中間附著按鈕群組 -->
            <div class="ts fluid attached buttons">
                <button onclick="num('1');" class="ts button">1</button>
                <button onclick="num('2');" class="ts button">2</button>
                <button onclick="num('3');" class="ts button">3</button>
                <button onclick="num('*');" class="ts info button">*</button>
            </div>
            <!-- / 中間附著按鈕群組 -->

            <!-- 底部附著按鈕群組 -->
            <div class="ts fluid bottom attached buttons">
			    <button onclick="num('3.1415926245359');" class="ts info button">π</button>
                <button onclick="num('0');" class="ts button">0</button>
                <button onclick="proc();" class="ts inverted button">=</button>
                <button onclick="num('/');" class="ts info button">/</button>
            </div>
            <!-- / 底部附著按鈕群組 -->
        </div>
	</div>
    <!-- / 主要文字容器 -->
    <!-- 來源：http://jsfiddle.net/fgmou8er/ -->

	 
	 <script>
	 var wipe= false;
	 var x=0;
	 function num(int){
		if (wipe==true){
		$("#panel").val('');
		}
	   $("#panel").val($("#panel").val() + int);
	 }
	 

	 function proc(){
		$("#panel").val(eval($("#panel").val()));
	 }
	 
	 </script>
</body>
</html>