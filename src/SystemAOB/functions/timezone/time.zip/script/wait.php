<?php
include '../../../../auth.php';
?>
<?
sleep($_GET["second"]);
echo "end"
?>