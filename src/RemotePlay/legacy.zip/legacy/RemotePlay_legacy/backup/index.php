<?php
include_once '../auth.php';
if (isset($_GET['filepath'])){
	header("Location: embedded.php?filepath=" . $_GET['filepath'] . "&filename=" . $_GET['filename']);
}
?>
<html>
<head>
    <link rel="stylesheet" href="../script/tocas/tocas.css">
	<script src="../script/tocas/tocas.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<script src="../script/jquery.min.js"></script>
	<script src="../script/ao_module.js"></script>
	<style>
	body{
		background-color:#0c0c0c;
		color:white;
	}
	.white{
		color:white !important;
	}
	.bottom{
		position:fixed;
		width:100%;
		height:35px;
		left:0px;
		bottom:0px;
		padding-bottom:5px;
		padding: 5px;
	}
	</style>
	</head>
<body>
<?php
$rid = rand(1000,9999);
?>
<br><br>
<div class="ts container" style="color:white;">
	<h3 class="ts center aligned icon header" style="color:white;">
		<i class="feed icon"></i>ArOZ Remote Play
    <div class="sub header" style="color:white;">Use this devices as a remote player or player remote!</div>
	<hr>
	</h3>
	<div align="center">
		<div class="white" style="font-size:2em;padding-top:10px;"><i class="hashtag icon"></i>Remote ID: <?php echo $rid;?></div>
		<p class="white" style="font-size:80%;">To use ArOZ Remote Play function, use the OpenWith from your active device and enter the above ID to play with this window.<br><i class="caution sign icon"></i>Warning! Only support Audio files.</p>
	</div>
	<br>
</div>
<div class="white bottom" align="right">
	<div class="ts breadcrumb">
		<a class="white section" href="remote.php">Toggle Remote</a>
		<div class="divider"> / </div>
		<a class="white section" href="">Refresh</a>
		<div class="divider"> / </div>
		<a class="white section">Clear Sessions</a>
		<div class="divider dirModeOnly"> / </div>
		<a class="white active section dirModeOnly" href="../">Exit</a>
	</div>
</div>
<div id="rid" style="display:none;"><?php echo $rid;?></div>
<script>
var rid = $("#rid").text().trim();
var audio = new Audio("");
audio.loop = true;
ao_module_setWindowSize(385,520);
ao_module_setWindowTitle("RemotePlay");
ao_module_setWindowIcon("feed");
if (ao_module_virtualDesktop){
	$(".dirModeOnly").hide();
}

setInterval(check,1000);

function check(){
	audio.volume = localStorage.getItem("global_volume");
	$.get("check.php?rid=" + rid,function(data){
		if (data.includes("ERROR") == false){
			if (data[0] == false){
				//Nothing is found
			}else{
				//There is content. Read it from JSON 
				var fileinfo = data[1];
				if (fileinfo[0] == "fopen"){
					//open the given filepath
					audio.pause();
					audio.currentTime = 0;
					audio.src = fileinfo[1];
					audio.play();
				}else if (fileinfo[0] == "setVol"){
					localStorage.setItem("global_volume",fileinfo[1]);
					audio.volume = localStorage.getItem("global_volume");
				}else if (fileinfo[0] == "play"){
					audio.play();
				}else if (fileinfo[0] == "pause"){
					audio.pause();
				}else if (fileinfo[0] == "stop"){
					audio.pause();
					audio.currentTime = 0;
				}
			}
		}
	});
}

</script>
</body>
</html>