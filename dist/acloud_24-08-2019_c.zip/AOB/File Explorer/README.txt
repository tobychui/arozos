AOB File Explorer Module
This is a dummy module for redirecting to SystemAOB/functions/file_system/index.php