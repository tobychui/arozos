SYSTEM AOB - The place where the core scripts of AOB is stored.
-------------------------------------------------------
Please refer to each of the documentation of the stand alone functions
or function group's control panel instructions.

AOB SYSTEM RELIES ON THE SYSTEM AOB TO WORK.
PLEASE DO NOT DELETE THIS FOLDER.
