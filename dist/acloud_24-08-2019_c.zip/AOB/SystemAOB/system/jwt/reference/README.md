# jwtphpjquery
A simple example that implements JSON Web Tokens using PHP and JQuery.

Visit my blog article on Medium for an explanation of these sample files.
https://medium.com/@crmcmullen/simple-example-using-json-web-tokens-with-php-and-jquery-c648a80854c
