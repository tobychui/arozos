<?php
var_dump(__DIR__);
include_once("test/test.php");

?>