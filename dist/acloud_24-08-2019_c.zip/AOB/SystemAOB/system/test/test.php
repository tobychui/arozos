<?php
var_dump(__DIR__);
?>