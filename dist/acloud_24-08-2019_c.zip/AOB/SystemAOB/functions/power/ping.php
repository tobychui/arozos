<?php
include '../../../auth.php';
?>
<?php
echo 'PONG!';
?>