<?php
include '../../../auth.php';
?>
<?php
echo 'DONE';
system('sudo reboot');
?>