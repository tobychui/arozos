import os 
os.system("sudo /etc/init.d/apache2 restart")