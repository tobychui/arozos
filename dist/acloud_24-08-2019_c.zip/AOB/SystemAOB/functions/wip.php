<?php
include '../../auth.php';
?>
<html>
<head>
<!-- Redirect to this page in iframe inorder to let the floatWindow host system kill this window-->
<title>Work In Progress</title>
<style>
.center {
    position: absolute;
    width: 200px;
    height: 50px;
    top: 50%;
    left: 50%;
    margin-left: -50px; /* margin is -0.5 * dimension */
    margin-top: -25px; 
	color:white;
}​
</style>
</head>
<body style="background-color:#0f0030;">
<div class='fullscreenDiv'>
    <div class="center">Work In Progress</div>
</div>​
</body>
</head>