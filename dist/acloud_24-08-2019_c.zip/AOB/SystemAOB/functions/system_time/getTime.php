<?php
include '../../../auth.php';
?>
<?php
//Output system time
echo time();
?>