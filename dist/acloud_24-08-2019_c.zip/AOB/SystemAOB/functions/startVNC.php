<?php
include '../../auth.php';
?>
﻿<?php
echo 'DONE';
system('x11vnc -ncache 10');
?>
