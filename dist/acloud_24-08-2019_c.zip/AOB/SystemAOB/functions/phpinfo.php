<?php
include '../../auth.php';
?>
<?php
phpinfo();
?>