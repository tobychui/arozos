from gpiozero import LED
from time import sleep

led = LED(4)
led.off()
