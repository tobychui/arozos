AOB Power Menu Shortcut Module
This is a dummy module for redirecting to SystemAOB/functions/power/index.php