<?php
//include 'auth.php';
?>
<!DOCTYPE HTML>
<head>
<meta name="viewport" content="width=device-width, initial-scale=0.7, shrink-to-fit=no">
<title>ArOZ Onlineβ</title>
<link rel="stylesheet" href="script/tocas/tocas.css">
<script src="script/tocas/tocas.js"></script>
<script src="script/jquery.min.js"></script>
</head>